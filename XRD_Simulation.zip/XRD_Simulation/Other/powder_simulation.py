"""x-ray powder diffraction simulation"""
import numpy as np
import matplotlib.pyplot as plt